# by luffycity.com

class School:
    def __init__(self, address):
        self.address = address


bj = School('北京校区')
sh = School('上海校区')
sz = School('深圳校区')


class Course(object):
    def __init__(self, name, period, price, school=None):
        self.name = name
        self.period = period
        self.price = price
        self.school = school


py1 = Course('Python全栈', 110, 19999, bj)
py2 = Course('Python全栈', 110, 19999, sh)
py3 = Course('Python全栈', 110, 19999, sz)

l1 = Course('Linux运维', 110, 19999, bj)
l2 = Course('Linux运维', 110, 19999, sh)

g1 = Course('Go开发', 119, 19999, bj)


class Grade(object):
    def __init__(self, name, people, introduce, course=None):
        self.name = name
        self.people = people
        self.introduce = introduce
        self.course = course

gr1 = Grade('全栈1期',20,'....',py1)
gr2 = Grade('全栈1期',20,'....',py2)

gr3 = Grade('Linux8期',20,'....',l2)




gr1.people
gr1.course.price
gr1.course.school.address





















