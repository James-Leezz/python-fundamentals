# by luffycity.com

CODE = {
    1001:'上传文件，从头开始上传'
}