# by luffycity.com

v = '\ue056'
print(v)