# by luffycity.com

import os

size = os.stat(r'D:\sylar\s15\day31\1.进度条.py').st_size
print(size)