# by luffycity.com

import uuid


v = str(uuid.uuid4())
print(v)