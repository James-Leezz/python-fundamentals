# by luffycity.com

class File:
    def __init__(self,file_path):
        self.file_path = file_path

    def file_read(self):
        pass

    def file_update(self):
        pass

    def file_delete(self):
        pass

    def file_add(self):
        pass

class Excel:
    def __init__(self,file_path):
        self.file_path = file_path

    def excel_read(self):
        pass

    def excel_update(self):
        pass

    def excel_delete(self):
        pass

    def excel_add(self):
        pass
