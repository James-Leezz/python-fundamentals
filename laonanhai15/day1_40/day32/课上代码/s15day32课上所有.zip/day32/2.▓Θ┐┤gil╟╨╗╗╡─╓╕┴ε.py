# by luffycity.com
import sys

v1 = sys.getcheckinterval()
print(v1)