# by luffycity.com

import socket

server = socket.socket()

server.bind(('192.168.13.155',8001))

server.listen(5)

while True:
    conn,addr = server.accept()
    # 字节类型
    while True:
        data = conn.recv(1024) # 阻塞
        if data == b'exit':
            break
        response = data + b' SB'
        conn.send(response)

    conn.close()